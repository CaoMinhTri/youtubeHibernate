package entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity  
@DiscriminatorValue("SD")  
public class SDVideo extends Video{

	public SDVideo(String title) {
		super(title);
		// TODO Auto-generated constructor stub
	}
	public SDVideo(){}
}
