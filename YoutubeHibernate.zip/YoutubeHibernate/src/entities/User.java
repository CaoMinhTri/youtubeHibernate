package entities;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import controller.StorageManager;



@Entity
@Table(name = "user")
public class User  {
	//annotation mapping
	@Id
	@GeneratedValue
	@Column(name = "userid")
	private int userid;
	@Column(name = "nickname", unique = true)
	private String NickName;
	@Column(name = "email", unique = true)
	private String Email;
	@OneToMany(mappedBy="user", cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	private Set<Video> listvideo = new HashSet<Video>();
	@OneToMany(mappedBy="user", cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	private Set<Comment> listcomment = new HashSet<Comment>();
	@OneToMany(mappedBy="user", cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	private Set<ActivityStream> listactivitystream = new HashSet<ActivityStream>();

	
	//Getter and setter
	public Set<ActivityStream> getListactivitystream() {
		return listactivitystream;
	}
	public void setListactivitystream(Set<ActivityStream> listactivitystream) {
		this.listactivitystream = listactivitystream;
	}
	public Set<Comment> getListcomment() {
		return listcomment;
	}
	public void setListcomment(Set<Comment> listcomment) {
		this.listcomment = listcomment;
	}
	public Set<Video> getListvideo() {
		return listvideo;
	}
	public void setListvideo(Set<Video> listvideo) {
		this.listvideo = listvideo;
	}
	public int getUserID() {
		return userid;
	}
	public void setUserID(int userID) {
		userid = userID;
	}
	public String getNickName() {
		return NickName;
	}
	public void setNickName(String nickName) {
		NickName = nickName;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	
	// Constructor
	public User(String nickName, String email) {
		super();
		NickName = nickName;
		Email = email;
	}
	public User() {
	}
	
	//Author video
	public void author(Video video){
		StorageManager storageManager = new StorageManager();
		Set<Video> listvideos = new HashSet<Video>();
		video.setUser(this);
		listvideos.add(video);
		ActivityStream activitystream = new ActivityStream(this);
		activitystream.setListvideo(listvideos);
		activitystream.setType("Author");
		storageManager.save(activitystream);
		
	}

}
