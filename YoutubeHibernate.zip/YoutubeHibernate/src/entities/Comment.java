package entities;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "comment")
public class Comment {
	//mapping annotation
	@Id
	@GeneratedValue
	@Column(name = "commentid")
	private int CommentID;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="userid")
	private User user;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="videoid")
	private Video video;
	@Column(name = "content")
	private String content;
	@Column(name = "date")
	private Date date = new Date();
	
	
	//Getter and Setter
	public int getCommentID() {
		return CommentID;
	}
		
	public void setCommentID(int commentID) {
		CommentID = commentID;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Video getVideo() {
		return video;
	}
	public void setVideo(Video video) {
		this.video = video;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}

	//Constructor
	public Comment(String content,Video video,  User user) {
		super();
		this.user = user;
		this.video = video;
		this.content = content;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormat.format(date);
	}
	public Comment() {

	}
	
	

}
