package entities;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity  
@DiscriminatorValue("HD")  
public class HDVideo extends Video{

	public HDVideo(String title) {
		super(title);
		// TODO Auto-generated constructor stub
	}
	
	public HDVideo(){}
}
