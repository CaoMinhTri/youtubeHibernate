package entities;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "video")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)  
@DiscriminatorColumn(name = "type",discriminatorType = DiscriminatorType.STRING)  
@DiscriminatorValue(value = "video") 
public class Video  {
	
	//annotation mapping
	@Id
	@GeneratedValue
	@Column(name = "videoid")
	private int VideoID;
	@Column(name = "title", unique = true)
	private String Title;
	@Temporal(TemporalType.DATE)
	@Column(name = "date")
	private Date date = new Date();
	@Column(name = "type" , insertable = false, updatable = false)
	private String Type;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="userid")
	private User user;
	@OneToMany(mappedBy="video", cascade=CascadeType.ALL, fetch=FetchType.EAGER)
	private Set<Comment> listcomment = new HashSet<Comment>();
	@ManyToMany(fetch = FetchType.LAZY, mappedBy="listvideo")
	private Set<ActivityStream> listactivitystream = new HashSet<ActivityStream>(); 
	
	// Getter and setter
	public Date getDate() {
		return date;
	}
	public Set<ActivityStream> getListactivitystream() {
		return listactivitystream;
	}
	public void setListactivitystream(Set<ActivityStream> listactivitystream) {
		this.listactivitystream = listactivitystream;
	}
	public Set<Comment> getListcomment() {
		return listcomment;
	}
	public void setListcomment(Set<Comment> listcomment) {
		this.listcomment = listcomment;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getTitle() {
		return Title;
	}
	public void setTitle(String title) {
		Title = title;
	}
	public int getVideoID() {
		return VideoID;
	}
	public void setVideoID(int videoID) {
		VideoID = videoID;
	}
	public String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}
	
	
	//Constructor
	public Video(String title) {
		super();
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormat.format(date);
		Title = title;
	}
	public Video() {

	}
	


	
}
