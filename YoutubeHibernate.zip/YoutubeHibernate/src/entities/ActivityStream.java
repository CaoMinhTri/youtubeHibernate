package entities;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "activitystream")
public class ActivityStream {
	//Mapping annotation
	
	@Id
	@GeneratedValue
	@Column(name = "activityid")
	private int ActivityStreamID;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="userid")
	private User user;
	@Column(name = "type")
	private String type;
	@Column(name = "date")
	private Date date = new Date();
	@ManyToMany(cascade = {CascadeType.ALL})
	@JoinTable(name="contain", 
				joinColumns={@JoinColumn(name="activityid")}, 
				inverseJoinColumns={@JoinColumn(name="videoid")})
	private Set<Video> listvideo = new HashSet<Video>();
	
	//Getter and Setter
	
	
	public int getActivityStreamID() {
		return ActivityStreamID;
	}
	public Set<Video> getListvideo() {
		return listvideo;
	}
	public void setListvideo(Set<Video> listvideo) {
		this.listvideo = listvideo;
	}
	public void setActivityStreamID(int activityStreamID) {
		ActivityStreamID = activityStreamID;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	
	//Constructor
	public ActivityStream(User user) {
		super();
		this.user = user;
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormat.format(date); 
	}
	public ActivityStream() {
	}
	

}
