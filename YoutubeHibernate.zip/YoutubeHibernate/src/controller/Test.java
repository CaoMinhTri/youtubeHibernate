package controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import entities.*;

public class Test {

	public static List<User> getUser() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		String hql = "from User";
		Transaction tx = null;
		List<User> listUser = new ArrayList<>();
		try {
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			listUser = query.list();
			tx.commit();

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			System.out.println(e);
		} finally {
			session.close();
		}

		return listUser;
	}

	public static List<Comment> getComment() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		String hql = "from Comment";
		Transaction tx = null;
		List<Comment> listComment = new ArrayList<>();
		try {
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			listComment = query.list();
			tx.commit();

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			System.out.println(e);
		}

		finally {
			session.close();
		}
		;
		return listComment;

	}

	// Exercise 1
	public static List<Video> exercise1() {
		Session session = HibernateUtil.getSessionFactory().openSession();

		String hql = "from Video";
		Transaction tx = null;
		List<Video> listVideo = new ArrayList<Video>();
		try {
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			listVideo = query.list();
			tx.commit();
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			listVideo = null;
			System.out.println(e);
		} finally {
			session.close();
		}
		;
		return listVideo;
	}

	// Exercise 2
	public static void exercise2(User user) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		String hql = "from Video where userid = :id";
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			Query query = session.createQuery(hql);
			query.setParameter("id", user.getUserID());
			List<Video> listVideo = query.list();
			tx.commit();
			for (Video video : listVideo) {
				System.out.println("VideoID: " + video.getVideoID()
						+ ". Title: " + video.getTitle());
			}
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			System.out.println(e);
		}

		finally {
			session.close();
		}
		;

	}

	// Exercise 3
	public static void exercise3(User user1, User user2) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		List<Video> listVideo = new ArrayList<Video>();
		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("select distinct v from Video v "
					+ "join v.listcomment c " + "where v.user = :user1 "
					+ " and c.user = :user2");
			query.setParameter("user1", user1);
			query.setParameter("user2", user2);
			listVideo = query.list();
			tx.commit();
			for (Video video : listVideo) {
				System.out.println("VideoID: " + video.getVideoID()
						+ ". Title: " + video.getTitle());
			}
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			System.out.println(e);
		}

		finally {
			session.close();
		}
		;

	}

	// Exercise 4
	public static void exercise4() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		List<Video> listVideo = new ArrayList<Video>();
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, -7);
		try {
			tx = session.beginTransaction();
			Query query = session.createQuery("select distinct v from Video v "
					+ "join v.listcomment c where c.date > :date ");
			query.setParameter("date", cal.getTime());
			listVideo = query.list();
			tx.commit();
			for (Video video : listVideo) {
				System.out.println("VideoID: " + video.getVideoID()
						+ ". Title: " + video.getTitle());
			}

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			System.out.println(e);
		}

		finally {
			session.close();
		}
		;

	}

	// Exercise 5

	public static void exercise5() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		List<Video> listVideo = new ArrayList<Video>();
		try {
			tx = session.beginTransaction();
			Query query = session
					.createQuery("select v from Video v "
							+ "join v.listcomment c group by c.video order by count(c.video) desc");
			listVideo = query.list();
			tx.commit();
			Video video = new Video();
			video = listVideo.get(0);
			System.out.println("VideoID: " + video.getVideoID() + ". Title: "
					+ video.getTitle());
		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			System.out.println(e);
		}

		finally {
			session.close();
		}
		;

	}

	public static void exercise6() {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction tx = null;
		List<User> listUser = new ArrayList<User>();
		try {
			tx = session.beginTransaction();
			Query query = session
					.createQuery("select distinct u from User u join u.listvideo v where v.Type = :type");
			query.setParameter("type", "HD");
			listUser = query.list();
			tx.commit();
			for (User user : listUser) {
				System.out.println("UserID: " + user.getUserID()
						+ ". Nick name: " + user.getNickName());
			}

		} catch (HibernateException e) {
			if (tx != null)
				tx.rollback();
			System.out.println(e);
		}

		finally {
			session.close();
		}
		;

	}

	// Exercise 6

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		exercise4();
	}

}
