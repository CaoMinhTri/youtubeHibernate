package controller;

import entities.*;


public class Execute {

	public static void main(String[] args) {
		StorageManager    storageManager = new StorageManager();
		storageManager.beginTransaction();
		User userOne = new User("ogg", "dgg@gmail.com");
		storageManager.save(userOne);
	
		Video videoOne = new SDVideo("My Dogs");
		storageManager.save(videoOne);
		userOne.author(videoOne);
		
		Comment commentOne = new Comment("I love my dogs, they are the best", videoOne, userOne);
		storageManager.save(commentOne);
		
		User userTwo = new User("Kitty", "kitty@animals.net");
		storageManager.save(userTwo);
		
		Comment commentTwo = new Comment("Dogs are soooo lame! " +  "My cats are way cooler!", videoOne, userTwo);
		storageManager.save(commentTwo);
		
		Comment commentThree = new Comment("I need to see that, before I " + "believe your bold claims!", videoOne, userOne);
		storageManager.save(commentThree);
		
		Video videoTwo = new HDVideo("Awesome Cat Action");
		storageManager.save(videoTwo);
		userTwo.author(videoTwo);
		
		Comment commentFour = new Comment("There you go: " + "<link-to:Awesome_Cat_Action>", videoOne, userTwo);
		storageManager.save(commentFour);
		
		Comment commentFive = new Comment("Woah, those are really cool cats! " + "And even in HD!", videoTwo, userOne);
		storageManager.save(commentFive);
		
		Video videoThree = new SDVideo("No Comment");
		storageManager.save(videoThree);
		userTwo.author(videoThree);
		storageManager.commitTransaction();
	}

}
