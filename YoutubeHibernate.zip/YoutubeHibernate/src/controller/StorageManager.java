package controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.Transaction;

import entities.*;


public class StorageManager {
	static Session session;
	static Transaction tx;
	
	public StorageManager(){}
	
	public void beginTransaction(){
		 session = HibernateUtil.getSessionFactory().openSession();
		 tx = session.beginTransaction();
	}
	public void commitTransaction(){
		 try {
			 tx.commit();
			
		    } catch (HibernateException ex) {
		    	 if (tx != null) {
			            tx.rollback();
			        }            
			        Logger.getLogger("con").info("Exception: " + ex.getMessage());
			        ex.printStackTrace(System.err);
		    }finally {
		    	 session.close(); 
			}
	}
	public void save(Object object){
		if(object instanceof Comment){
	 		session.save(object);	
	 		Set<Video> videos = new HashSet<Video>();	
	 		videos.add(((Comment) object).getVideo());
	 		ActivityStream activityStream = new ActivityStream(((Comment) object).getUser());	
			activityStream.setListvideo(videos);
	 		activityStream.setType("Comment");	 		
	 		session.save(activityStream);
		}
	 	else{
			session.save(object);
	 		}
		
	}

}
